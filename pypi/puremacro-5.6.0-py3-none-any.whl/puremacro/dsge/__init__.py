"""DSGE primitives for puremacro.

Includes:
- Klein (2000) QZ solver for linear rational-expectations models.
- ``build``: write equilibrium conditions as a Python function and get a
  solved first-order approximation back, with the Jacobians taken by
  complex-step differentiation (no hand-derived matrices, no Dynare).
- Sims (2002) gensys solver (equivalent, model-agnostic input form).
- Bayesian estimation engine (random-walk Metropolis-Hastings) +
  model-agnostic priors framework.
- Smets-Wouters (2007) reference model + bundled US dataset.
- Matrix-free stacked-time Newton-Krylov for perfect-foresight systems
  (``solve_stacked_newton_krylov``; opt-in, separate from
  ``solve_perfect_foresight``).

For likelihood-based estimation, pair the state-space form returned by
``make_state_space`` (model-specific) with ``puremacro.dsge.estimate_dsge``.
"""
from .klein import BlanchardKahnError, KleinSolution, klein_solve
from .build import LinearModel, ModelError, SteadyStateError, build
from .steady import (
    StructuralSingularityError,
    StructuralSingularityWarning,
    allow_structural_singularity,
    steady,
)
from ._moments import one_sided_hp_filter
from ._results import (
    DSGEPosteriorResult, SW07PosteriorResult, NUTSResult, HANKResult,
    DynareDR, Dynare2ndDR, TheoreticalMomentsResult,
    StochSimulResult, DynareCommandResults, DynareCommandInvocation,
    SmootherResult, DSGEForecastResult, ModeCheckResult,
    DiagnosticFinding, EigenvalueTable, ModelDiagnosticsResult,
    IdentificationResult,
    OSRResult, PolicyResult, DiscretionaryPolicyResult,
    ExtendedPathResult,
    ConditionalForecastResult,
    ShockDecompositionResult,
    BayesianIRFResult,
    PriorPredictiveResult,
    ModelParityResult,
    ParityDashboardResult,
)
from .dsge_var import DSGEVARResult, estimate_dsge_var
from .hank import HANKModel, load_hank_mod, solve_hank_bridge
from .parity import verify_dynare_parity, compare_model_to_dynare, run_parity_suite
from .dynare_results import load_dynare_dr, load_dynare_moments, load_irfs, load_fevd
from .conditional import conditional_forecast
from .shock_groups import shock_groups_decomposition
from .bayesian import bayesian_irf, prior_predictive
from .diagnostics import check, resid, model_diagnostics
from .identification import identification
from .policy import osr, discretionary_policy, lq_commitment, optimal_policy
from .estimate import estimate_dsge
from .nuts import nuts_sample
from ._gradients import ScoreDiagnosticsResult
from .bayesian import BayesianEstimationResult, estimate_dsge_bayesian
from .sw07_estimate import estimate_sw07
from .sw07_data import load_sw07_data
from .sw07_marginal import SW07MarginalLikelihoodResult, sw07_laplace_mdd, sw07_log_posterior
from .pruning import (
    PrunedDSGESolution,
    PrunedSimulationResult,
    canonical_growth_2nd_order,
)
from .macro import DynareMacroError, Scope, preprocess_macro
from .dynare import (
    DynareFeatureError,
    build_dynare, parse_mod, load_mod, load_dynare_mod, solve_dynare_2nd_order,
    _orig_stoch_simul, _linear_model_stoch_simul,
)
from .inspection import inspect_mod, ModInspectionReport, ModStatement, ModIssue, ModSourceSpan
from ._mod_execution import ModCompatibilityError, ModExecutionError
from .perfect_foresight import PerfectForesightResult, solve_perfect_foresight
from .extended_path import extended_path
from .stacked_newton import (
    BlockTridiagonalPreconditioner,
    HorizonComparison,
    StackedNewtonError,
    StackedNewtonResult,
    StackedProblem,
    StructuredBlockTridiagonalPreconditioner,
    compare_stacked_horizons,
    preconditioned_lgmres,
    solve_stacked_newton_krylov,
)
from .occbin import (
    OccBinConstraint,
    OccBinResult,
    DifferentiableOccBinResult,
    solve_occbin,
    solve_multiconstraint_occbin,
    solve_differentiable_occbin,
    solve_pruned_occbin,
    smin_tau,
    smax_tau,
    d_smax_tau,
    d_smin_tau,
    smooth_min,
    smooth_max,
    d_smooth_max,
    d_smooth_min,
    fischer_burmeister,
    grad_fischer_burmeister,
    Phi_tau,
)
from .gertler_karadi import (
    GK2011_PARAMS,
    GertlerKaradiResult,
    build_gertler_karadi_model,
    solve_gertler_karadi,
    solve_steady_state,
)
from .priors import (
    Prior,
    BetaPrior,
    InvGammaPrior,
    NormalPrior,
    GammaPrior,
    UniformPrior,
    WeibullPrior,
)
from .decomposition import (
    FEVDResult,
    ShockDecompResult,
    compute_fevd,
    compute_shock_decomposition,
)
from ._estimated_params import (
    EstimatedParams,
    EstimatedParamSpec,
    parse_estimated_params,
    parse_estimated_params_bounds,
    parse_estimated_params_init,
)
from .observation import make_state_space_from_varobs
from .smoother import forecast_model, smooth_model
from .mode import cmaes, csminwel, find_mode, mode_check
from .marginal import (
    HarmonicMeanResult,
    harmonic_mean_mdd,
    laplace_mdd,
    model_comparison,
)
from .news import (
    NewsIRFResult,
    NewsDecompositionResult,
    news_irf,
    decompose_news,
    plot_news_vs_surprise,
)
from .particle_filter import (
    ParticleFilterResult,
    StochasticVolatilitySpec,
    multinomial_resample,
    particle_filter,
    residual_resample,
    stratified_resample,
    systematic_resample,
)
from .markov_switching import (
    MSDSGEResult,
    solve_ms_dsge,
)
from . import priors
from . import marginal, mode, observation, smoother, news


__all__ = [
    "inspect_mod", "ModInspectionReport", "ModStatement", "ModIssue", "ModSourceSpan",
    "ModCompatibilityError", "ModExecutionError", "DynareCommandResults", "DynareCommandInvocation",
    "klein_solve", "KleinSolution", "BlanchardKahnError",
    "build", "LinearModel", "ModelError", "SteadyStateError",
    "steady", "StructuralSingularityError", "StructuralSingularityWarning",
    "allow_structural_singularity",
    "DSGEPosteriorResult", "SW07PosteriorResult", "NUTSResult", "BayesianEstimationResult",
    "ScoreDiagnosticsResult", "nuts_sample",
    "DynareDR", "Dynare2ndDR", "TheoreticalMomentsResult", "StochSimulResult",
    "build_dynare", "parse_mod", "load_mod", "load_dynare_mod", "solve_dynare_2nd_order",
    "DynareFeatureError",
    "PerfectForesightResult", "solve_perfect_foresight",
    # --- Stacked-time Newton-Krylov (opt-in perfect-foresight core) ---------
    "StackedProblem", "BlockTridiagonalPreconditioner", "StructuredBlockTridiagonalPreconditioner",
    "preconditioned_lgmres", "solve_stacked_newton_krylov", "compare_stacked_horizons",
    "StackedNewtonResult", "HorizonComparison", "StackedNewtonError",
    "OccBinConstraint", "OccBinResult", "solve_occbin", "solve_multiconstraint_occbin", "solve_pruned_occbin",
    "solve_gertler_karadi", "GertlerKaradiResult", "GK2011_PARAMS", "solve_steady_state", "build_gertler_karadi_model",
    "estimate_dsge", "estimate_dsge_bayesian", "estimate_sw07",
    "load_sw07_data", "sw07_laplace_mdd", "sw07_log_posterior", "SW07MarginalLikelihoodResult",
    "PrunedDSGESolution", "PrunedSimulationResult", "canonical_growth_2nd_order",
    "FEVDResult", "ShockDecompResult", "compute_fevd", "compute_shock_decomposition",
    "Prior", "BetaPrior", "InvGammaPrior", "NormalPrior", "GammaPrior", "UniformPrior",
    "WeibullPrior",
    # --- 2.6.0: .mod file to posterior -----------------------------------
    "EstimatedParams", "EstimatedParamSpec", "parse_estimated_params",
    "parse_estimated_params_init", "parse_estimated_params_bounds",
    "make_state_space_from_varobs",
    "SmootherResult", "DSGEForecastResult", "smooth_model", "forecast_model",
    "find_mode", "mode_check", "csminwel", "cmaes", "ModeCheckResult",
    "laplace_mdd", "harmonic_mean_mdd", "model_comparison", "HarmonicMeanResult",
    "marginal", "mode", "observation", "smoother",
    "priors",
    # --- 2.6.0: DSGE Diagnostics & Residuals ------------------------------
    "check", "resid", "model_diagnostics",
    "EigenvalueTable", "ModelDiagnosticsResult", "DiagnosticFinding",
    # --- 2.6.0: Parameter Identification Analysis ------------------------
    "identification", "IdentificationResult",
    # --- 2.6.0: Optimal Simple Rules & Policy Regimes --------------------
    "osr", "discretionary_policy", "lq_commitment", "optimal_policy",
    "OSRResult", "PolicyResult", "DiscretionaryPolicyResult",
    # --- 2.9.0: stoch_simul Filtering & Simulation Surface ---------------
    "one_sided_hp_filter",
    # --- 2.9.0: Extended Path (Fair-Taylor 1983) -------------------------
    "extended_path", "ExtendedPathResult",
    # --- 2.9.0: Tier 3 Surface -------------------------------------------
    "conditional_forecast", "ConditionalForecastResult",
    "shock_groups_decomposition", "ShockDecompositionResult",
    "bayesian_irf", "BayesianIRFResult",
    "prior_predictive", "PriorPredictiveResult",
    # --- 2.9.0: Dynare Parity Dashboard & CLI ----------------------------
    "verify_dynare_parity", "compare_model_to_dynare", "run_parity_suite",
    "load_dynare_dr", "load_dynare_moments", "load_irfs", "load_fevd",
    "ParityDashboardResult", "ModelParityResult",
    "dynare_results", "parity",
    # --- 3.0.0: Sequence-Space HANK Bridge -------------------------------
    "HANKModel", "HANKResult", "load_hank_mod", "solve_hank_bridge",
    "hank",
    # --- Dynare Macro Processor & Interactive Widgets --------------------
    "preprocess_macro", "DynareMacroError", "Scope",
    "interactive_irf", "InteractiveIRFResult",
    "macro", "widgets",
    # --- Del Negro & Schorfheide (2004) DSGE-VAR Hybrid Modeling ---------
    "estimate_dsge_var", "DSGEVARResult",
    # --- Milestone 3: News & Anticipated Shocks Engine -------------------
    "NewsIRFResult", "NewsDecompositionResult", "news_irf", "decompose_news", "plot_news_vs_surprise",
    "news",
    # --- Phase D: Particle Filtering & Markov-Switching DSGE -------------
    "particle_filter", "ParticleFilterResult", "StochasticVolatilitySpec",
    "systematic_resample", "stratified_resample", "residual_resample", "multinomial_resample",
    "solve_ms_dsge", "MSDSGEResult",
    "markov_switching",
]
from . import smets_wouters  # re-export for back-compat with 0.50.0 callers
from . import gertler_karadi
from . import dynare_results, parity
from . import hank
from . import macro
from . import news
from . import markov_switching
from . import estimate
import types as _types


class _EstimateModule(_types.ModuleType):
    """Module proxy allowing puremacro.dsge.estimate to act as both module and callable function."""

    def __call__(self, *args, **kwargs):
        from .estimate import estimate as _estimate_func
        return _estimate_func(*args, **kwargs)


estimate.__class__ = _EstimateModule

# Convenience aliases so particle_filter function can also act like module export
setattr(particle_filter, "particle_filter", particle_filter)
setattr(particle_filter, "ParticleFilterResult", ParticleFilterResult)
setattr(particle_filter, "StochasticVolatilitySpec", StochasticVolatilitySpec)
setattr(particle_filter, "systematic_resample", systematic_resample)
setattr(particle_filter, "stratified_resample", stratified_resample)
setattr(particle_filter, "residual_resample", residual_resample)
setattr(particle_filter, "multinomial_resample", multinomial_resample)







def __getattr__(name: str):
    """Defer the interactive-widget entry points until first use.

    ``puremacro.dsge.widgets`` builds Matplotlib slider/button figures, so
    importing it eagerly pulled the whole plotting stack into every
    ``import puremacro.dsge``.  Exposing ``InteractiveIRFResult`` and
    ``interactive_irf`` through :pep:`562` module ``__getattr__`` keeps the
    public names available while leaving Matplotlib unimported until one of
    them is actually touched.
    """
    if name in ("InteractiveIRFResult", "interactive_irf", "widgets"):
        import importlib

        _widgets = importlib.import_module(f"{__name__}.widgets")
        globals()["widgets"] = _widgets
        globals()["interactive_irf"] = _widgets.interactive_irf
        globals()["InteractiveIRFResult"] = _widgets.InteractiveIRFResult
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
